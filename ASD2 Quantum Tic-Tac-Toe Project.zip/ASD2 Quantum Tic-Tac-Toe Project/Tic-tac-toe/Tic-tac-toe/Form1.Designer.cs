﻿namespace Tic_tac_toe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.misèreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quantumToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rulesAndReferencesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classicToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.misèreToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.quantumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bC9 = new System.Windows.Forms.Button();
            this.bC8 = new System.Windows.Forms.Button();
            this.bC7 = new System.Windows.Forms.Button();
            this.bC6 = new System.Windows.Forms.Button();
            this.bC5 = new System.Windows.Forms.Button();
            this.bC4 = new System.Windows.Forms.Button();
            this.bC3 = new System.Windows.Forms.Button();
            this.bC2 = new System.Windows.Forms.Button();
            this.bC1 = new System.Windows.Forms.Button();
            this.panelQ = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.panel11 = new System.Windows.Forms.Panel();
            this.bM9 = new System.Windows.Forms.Button();
            this.bM8 = new System.Windows.Forms.Button();
            this.bM7 = new System.Windows.Forms.Button();
            this.bM6 = new System.Windows.Forms.Button();
            this.bM5 = new System.Windows.Forms.Button();
            this.bM4 = new System.Windows.Forms.Button();
            this.bM3 = new System.Windows.Forms.Button();
            this.bM2 = new System.Windows.Forms.Button();
            this.bM1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelQ.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.rulesAndReferencesToolStripMenuItem,
            this.creditsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(2968, 52);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classicToolStripMenuItem,
            this.misèreToolStripMenuItem,
            this.quantumToolStripMenuItem1});
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(173, 48);
            this.newGameToolStripMenuItem.Text = "New game";
            // 
            // classicToolStripMenuItem
            // 
            this.classicToolStripMenuItem.Name = "classicToolStripMenuItem";
            this.classicToolStripMenuItem.Size = new System.Drawing.Size(257, 46);
            this.classicToolStripMenuItem.Text = "Classic";
            this.classicToolStripMenuItem.Click += new System.EventHandler(this.classicToolStripMenuItem_Click);
            // 
            // misèreToolStripMenuItem
            // 
            this.misèreToolStripMenuItem.Name = "misèreToolStripMenuItem";
            this.misèreToolStripMenuItem.Size = new System.Drawing.Size(257, 46);
            this.misèreToolStripMenuItem.Text = "Misère ";
            this.misèreToolStripMenuItem.Click += new System.EventHandler(this.misèreToolStripMenuItem1_Click);
            // 
            // quantumToolStripMenuItem1
            // 
            this.quantumToolStripMenuItem1.Name = "quantumToolStripMenuItem1";
            this.quantumToolStripMenuItem1.Size = new System.Drawing.Size(257, 46);
            this.quantumToolStripMenuItem1.Text = "Quantum";
            this.quantumToolStripMenuItem1.Click += new System.EventHandler(this.quantumToolStripMenuItem_Click);
            // 
            // rulesAndReferencesToolStripMenuItem
            // 
            this.rulesAndReferencesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classicToolStripMenuItem1,
            this.misèreToolStripMenuItem1,
            this.quantumToolStripMenuItem});
            this.rulesAndReferencesToolStripMenuItem.Name = "rulesAndReferencesToolStripMenuItem";
            this.rulesAndReferencesToolStripMenuItem.Size = new System.Drawing.Size(304, 48);
            this.rulesAndReferencesToolStripMenuItem.Text = "Rules and references";
            // 
            // classicToolStripMenuItem1
            // 
            this.classicToolStripMenuItem1.Name = "classicToolStripMenuItem1";
            this.classicToolStripMenuItem1.Size = new System.Drawing.Size(257, 46);
            this.classicToolStripMenuItem1.Text = "Classic";
            this.classicToolStripMenuItem1.Click += new System.EventHandler(this.classic2ToolStripMenuItem_Click);
            // 
            // misèreToolStripMenuItem1
            // 
            this.misèreToolStripMenuItem1.Name = "misèreToolStripMenuItem1";
            this.misèreToolStripMenuItem1.Size = new System.Drawing.Size(257, 46);
            this.misèreToolStripMenuItem1.Text = "Misère";
            this.misèreToolStripMenuItem1.Click += new System.EventHandler(this.misère2ToolStripMenuItem1_Click);
            // 
            // quantumToolStripMenuItem
            // 
            this.quantumToolStripMenuItem.Name = "quantumToolStripMenuItem";
            this.quantumToolStripMenuItem.Size = new System.Drawing.Size(257, 46);
            this.quantumToolStripMenuItem.Text = "Quantum";
            this.quantumToolStripMenuItem.Click += new System.EventHandler(this.quantum2ToolStripMenuItem_Click);
            // 
            // creditsToolStripMenuItem
            // 
            this.creditsToolStripMenuItem.Name = "creditsToolStripMenuItem";
            this.creditsToolStripMenuItem.Size = new System.Drawing.Size(123, 48);
            this.creditsToolStripMenuItem.Text = "Credits";
            this.creditsToolStripMenuItem.Click += new System.EventHandler(this.creditsToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bC9);
            this.panel1.Controls.Add(this.bC8);
            this.panel1.Controls.Add(this.bC7);
            this.panel1.Controls.Add(this.bC6);
            this.panel1.Controls.Add(this.bC5);
            this.panel1.Controls.Add(this.bC4);
            this.panel1.Controls.Add(this.bC3);
            this.panel1.Controls.Add(this.bC2);
            this.panel1.Controls.Add(this.bC1);
            this.panel1.Location = new System.Drawing.Point(12, 55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1024, 1024);
            this.panel1.TabIndex = 1;
            this.panel1.Visible = false;
            // 
            // bC9
            // 
            this.bC9.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC9.Location = new System.Drawing.Point(615, 595);
            this.bC9.Name = "bC9";
            this.bC9.Size = new System.Drawing.Size(256, 256);
            this.bC9.TabIndex = 8;
            this.bC9.UseVisualStyleBackColor = true;
            this.bC9.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC8
            // 
            this.bC8.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC8.Location = new System.Drawing.Point(353, 595);
            this.bC8.Name = "bC8";
            this.bC8.Size = new System.Drawing.Size(256, 256);
            this.bC8.TabIndex = 7;
            this.bC8.UseVisualStyleBackColor = true;
            this.bC8.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC7
            // 
            this.bC7.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC7.Location = new System.Drawing.Point(91, 595);
            this.bC7.Name = "bC7";
            this.bC7.Size = new System.Drawing.Size(256, 256);
            this.bC7.TabIndex = 6;
            this.bC7.UseVisualStyleBackColor = true;
            this.bC7.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC6
            // 
            this.bC6.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC6.Location = new System.Drawing.Point(615, 333);
            this.bC6.Name = "bC6";
            this.bC6.Size = new System.Drawing.Size(256, 256);
            this.bC6.TabIndex = 5;
            this.bC6.UseVisualStyleBackColor = true;
            this.bC6.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC5
            // 
            this.bC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC5.Location = new System.Drawing.Point(353, 333);
            this.bC5.Name = "bC5";
            this.bC5.Size = new System.Drawing.Size(256, 256);
            this.bC5.TabIndex = 4;
            this.bC5.UseVisualStyleBackColor = true;
            this.bC5.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC4
            // 
            this.bC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC4.Location = new System.Drawing.Point(91, 333);
            this.bC4.Name = "bC4";
            this.bC4.Size = new System.Drawing.Size(256, 256);
            this.bC4.TabIndex = 3;
            this.bC4.UseVisualStyleBackColor = true;
            this.bC4.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC3
            // 
            this.bC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC3.Location = new System.Drawing.Point(615, 71);
            this.bC3.Name = "bC3";
            this.bC3.Size = new System.Drawing.Size(256, 256);
            this.bC3.TabIndex = 2;
            this.bC3.UseVisualStyleBackColor = true;
            this.bC3.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC2
            // 
            this.bC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC2.Location = new System.Drawing.Point(353, 71);
            this.bC2.Name = "bC2";
            this.bC2.Size = new System.Drawing.Size(256, 256);
            this.bC2.TabIndex = 1;
            this.bC2.UseVisualStyleBackColor = true;
            this.bC2.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // bC1
            // 
            this.bC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bC1.Location = new System.Drawing.Point(91, 71);
            this.bC1.Name = "bC1";
            this.bC1.Size = new System.Drawing.Size(256, 256);
            this.bC1.TabIndex = 0;
            this.bC1.UseVisualStyleBackColor = true;
            this.bC1.Click += new System.EventHandler(this.Cbutton_click);
            // 
            // panelQ
            // 
            this.panelQ.Controls.Add(this.panel10);
            this.panelQ.Controls.Add(this.panel9);
            this.panelQ.Controls.Add(this.panel8);
            this.panelQ.Controls.Add(this.panel7);
            this.panelQ.Controls.Add(this.panel6);
            this.panelQ.Controls.Add(this.panel5);
            this.panelQ.Controls.Add(this.panel4);
            this.panelQ.Controls.Add(this.panel3);
            this.panelQ.Controls.Add(this.panel2);
            this.panelQ.Location = new System.Drawing.Point(1030, 52);
            this.panelQ.Name = "panelQ";
            this.panelQ.Size = new System.Drawing.Size(1024, 1024);
            this.panelQ.TabIndex = 0;
            this.panelQ.Visible = false;
            this.panelQ.Paint += new System.Windows.Forms.PaintEventHandler(this.panelQ_Paint);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.button73);
            this.panel10.Controls.Add(this.button74);
            this.panel10.Controls.Add(this.button75);
            this.panel10.Controls.Add(this.button76);
            this.panel10.Controls.Add(this.button77);
            this.panel10.Controls.Add(this.button78);
            this.panel10.Controls.Add(this.button79);
            this.panel10.Controls.Add(this.button80);
            this.panel10.Controls.Add(this.button81);
            this.panel10.Location = new System.Drawing.Point(719, 702);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(270, 273);
            this.panel10.TabIndex = 25;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(180, 183);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(84, 84);
            this.button73.TabIndex = 16;
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(0, 3);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(84, 84);
            this.button74.TabIndex = 0;
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(90, 183);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(84, 84);
            this.button75.TabIndex = 15;
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(90, 3);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(84, 84);
            this.button76.TabIndex = 1;
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(0, 183);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(84, 84);
            this.button77.TabIndex = 14;
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(180, 3);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(84, 84);
            this.button78.TabIndex = 10;
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(180, 93);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(84, 84);
            this.button79.TabIndex = 13;
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(0, 93);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(84, 84);
            this.button80.TabIndex = 11;
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(90, 93);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(84, 84);
            this.button81.TabIndex = 12;
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.button64);
            this.panel9.Controls.Add(this.button65);
            this.panel9.Controls.Add(this.button66);
            this.panel9.Controls.Add(this.button67);
            this.panel9.Controls.Add(this.button68);
            this.panel9.Controls.Add(this.button69);
            this.panel9.Controls.Add(this.button70);
            this.panel9.Controls.Add(this.button71);
            this.panel9.Controls.Add(this.button72);
            this.panel9.Location = new System.Drawing.Point(405, 699);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(270, 273);
            this.panel9.TabIndex = 24;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(180, 183);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(84, 84);
            this.button64.TabIndex = 16;
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(0, 3);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(84, 84);
            this.button65.TabIndex = 0;
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(90, 183);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(84, 84);
            this.button66.TabIndex = 15;
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(90, 3);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(84, 84);
            this.button67.TabIndex = 1;
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(0, 183);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(84, 84);
            this.button68.TabIndex = 14;
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(180, 3);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(84, 84);
            this.button69.TabIndex = 10;
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(180, 93);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(84, 84);
            this.button70.TabIndex = 13;
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(0, 93);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(84, 84);
            this.button71.TabIndex = 11;
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(90, 93);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(84, 84);
            this.button72.TabIndex = 12;
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button55);
            this.panel8.Controls.Add(this.button56);
            this.panel8.Controls.Add(this.button57);
            this.panel8.Controls.Add(this.button58);
            this.panel8.Controls.Add(this.button59);
            this.panel8.Controls.Add(this.button60);
            this.panel8.Controls.Add(this.button61);
            this.panel8.Controls.Add(this.button62);
            this.panel8.Controls.Add(this.button63);
            this.panel8.Location = new System.Drawing.Point(91, 699);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(270, 273);
            this.panel8.TabIndex = 23;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(180, 183);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(84, 84);
            this.button55.TabIndex = 16;
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(0, 3);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(84, 84);
            this.button56.TabIndex = 0;
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(90, 183);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(84, 84);
            this.button57.TabIndex = 15;
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(90, 3);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(84, 84);
            this.button58.TabIndex = 1;
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(0, 183);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(84, 84);
            this.button59.TabIndex = 14;
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(180, 3);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(84, 84);
            this.button60.TabIndex = 10;
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(180, 93);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(84, 84);
            this.button61.TabIndex = 13;
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(0, 93);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(84, 84);
            this.button62.TabIndex = 11;
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(90, 93);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(84, 84);
            this.button63.TabIndex = 12;
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button46);
            this.panel7.Controls.Add(this.button47);
            this.panel7.Controls.Add(this.button48);
            this.panel7.Controls.Add(this.button49);
            this.panel7.Controls.Add(this.button50);
            this.panel7.Controls.Add(this.button51);
            this.panel7.Controls.Add(this.button52);
            this.panel7.Controls.Add(this.button53);
            this.panel7.Controls.Add(this.button54);
            this.panel7.Location = new System.Drawing.Point(722, 392);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(270, 273);
            this.panel7.TabIndex = 22;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(180, 183);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(84, 84);
            this.button46.TabIndex = 16;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(0, 3);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(84, 84);
            this.button47.TabIndex = 0;
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(90, 183);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(84, 84);
            this.button48.TabIndex = 15;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(90, 3);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(84, 84);
            this.button49.TabIndex = 1;
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(0, 183);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(84, 84);
            this.button50.TabIndex = 14;
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(180, 3);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(84, 84);
            this.button51.TabIndex = 10;
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(180, 93);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(84, 84);
            this.button52.TabIndex = 13;
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(0, 93);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(84, 84);
            this.button53.TabIndex = 11;
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(90, 93);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(84, 84);
            this.button54.TabIndex = 12;
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button37);
            this.panel6.Controls.Add(this.button38);
            this.panel6.Controls.Add(this.button39);
            this.panel6.Controls.Add(this.button40);
            this.panel6.Controls.Add(this.button41);
            this.panel6.Controls.Add(this.button42);
            this.panel6.Controls.Add(this.button43);
            this.panel6.Controls.Add(this.button44);
            this.panel6.Controls.Add(this.button45);
            this.panel6.Location = new System.Drawing.Point(405, 389);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(270, 273);
            this.panel6.TabIndex = 21;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(180, 183);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(84, 84);
            this.button37.TabIndex = 16;
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(0, 3);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(84, 84);
            this.button38.TabIndex = 0;
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(90, 183);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(84, 84);
            this.button39.TabIndex = 15;
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(90, 3);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(84, 84);
            this.button40.TabIndex = 1;
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(0, 183);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(84, 84);
            this.button41.TabIndex = 14;
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(180, 3);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(84, 84);
            this.button42.TabIndex = 10;
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(180, 93);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(84, 84);
            this.button43.TabIndex = 13;
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(0, 93);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(84, 84);
            this.button44.TabIndex = 11;
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(90, 93);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(84, 84);
            this.button45.TabIndex = 12;
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button28);
            this.panel5.Controls.Add(this.button29);
            this.panel5.Controls.Add(this.button30);
            this.panel5.Controls.Add(this.button31);
            this.panel5.Controls.Add(this.button32);
            this.panel5.Controls.Add(this.button33);
            this.panel5.Controls.Add(this.button34);
            this.panel5.Controls.Add(this.button35);
            this.panel5.Controls.Add(this.button36);
            this.panel5.Location = new System.Drawing.Point(91, 389);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(270, 273);
            this.panel5.TabIndex = 20;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(180, 183);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(84, 84);
            this.button28.TabIndex = 16;
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(0, 3);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(84, 84);
            this.button29.TabIndex = 0;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(90, 183);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(84, 84);
            this.button30.TabIndex = 15;
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(90, 3);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(84, 84);
            this.button31.TabIndex = 1;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(0, 183);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(84, 84);
            this.button32.TabIndex = 14;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(180, 3);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(84, 84);
            this.button33.TabIndex = 10;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(180, 93);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(84, 84);
            this.button34.TabIndex = 13;
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(0, 93);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(84, 84);
            this.button35.TabIndex = 11;
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(90, 93);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(84, 84);
            this.button36.TabIndex = 12;
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button19);
            this.panel4.Controls.Add(this.button20);
            this.panel4.Controls.Add(this.button21);
            this.panel4.Controls.Add(this.button22);
            this.panel4.Controls.Add(this.button23);
            this.panel4.Controls.Add(this.button24);
            this.panel4.Controls.Add(this.button25);
            this.panel4.Controls.Add(this.button26);
            this.panel4.Controls.Add(this.button27);
            this.panel4.Location = new System.Drawing.Point(719, 74);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(270, 273);
            this.panel4.TabIndex = 19;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(180, 183);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(84, 84);
            this.button19.TabIndex = 16;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(0, 3);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(84, 84);
            this.button20.TabIndex = 0;
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(90, 183);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(84, 84);
            this.button21.TabIndex = 15;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(90, 3);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(84, 84);
            this.button22.TabIndex = 1;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(0, 183);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(84, 84);
            this.button23.TabIndex = 14;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(180, 3);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(84, 84);
            this.button24.TabIndex = 10;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(180, 93);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(84, 84);
            this.button25.TabIndex = 13;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(0, 93);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(84, 84);
            this.button26.TabIndex = 11;
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(90, 93);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(84, 84);
            this.button27.TabIndex = 12;
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button10);
            this.panel3.Controls.Add(this.button11);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.button13);
            this.panel3.Controls.Add(this.button14);
            this.panel3.Controls.Add(this.button15);
            this.panel3.Controls.Add(this.button16);
            this.panel3.Controls.Add(this.button17);
            this.panel3.Controls.Add(this.button18);
            this.panel3.Location = new System.Drawing.Point(405, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(270, 273);
            this.panel3.TabIndex = 18;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(4, 4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(84, 84);
            this.button10.TabIndex = 16;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(90, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(84, 84);
            this.button11.TabIndex = 0;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(180, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(84, 84);
            this.button12.TabIndex = 15;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(3, 93);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(84, 84);
            this.button13.TabIndex = 1;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(90, 93);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(84, 84);
            this.button14.TabIndex = 14;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(180, 90);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(84, 84);
            this.button15.TabIndex = 10;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(3, 182);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(84, 84);
            this.button16.TabIndex = 13;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(90, 180);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(84, 84);
            this.button17.TabIndex = 11;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(180, 180);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(84, 84);
            this.button18.TabIndex = 12;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button9);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Location = new System.Drawing.Point(86, 71);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(270, 273);
            this.panel2.TabIndex = 17;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(180, 183);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(84, 84);
            this.button9.TabIndex = 16;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 84);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(90, 183);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(84, 84);
            this.button8.TabIndex = 15;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(90, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 84);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(0, 183);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(84, 84);
            this.button7.TabIndex = 14;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(180, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 84);
            this.button3.TabIndex = 10;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(180, 93);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(84, 84);
            this.button6.TabIndex = 13;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(0, 93);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(84, 84);
            this.button4.TabIndex = 11;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // button5
            // 
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.Location = new System.Drawing.Point(90, 93);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(84, 84);
            this.button5.TabIndex = 12;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Qbutton_click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            this.fileSystemWatcher1.Changed += new System.IO.FileSystemEventHandler(this.fileSystemWatcher1_Changed);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.bM9);
            this.panel11.Controls.Add(this.bM8);
            this.panel11.Controls.Add(this.bM7);
            this.panel11.Controls.Add(this.bM6);
            this.panel11.Controls.Add(this.bM5);
            this.panel11.Controls.Add(this.bM4);
            this.panel11.Controls.Add(this.bM3);
            this.panel11.Controls.Add(this.bM2);
            this.panel11.Controls.Add(this.bM1);
            this.panel11.Location = new System.Drawing.Point(2060, 65);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1024, 1024);
            this.panel11.TabIndex = 9;
            this.panel11.Visible = false;
            // 
            // bM9
            // 
            this.bM9.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM9.Location = new System.Drawing.Point(615, 595);
            this.bM9.Name = "bM9";
            this.bM9.Size = new System.Drawing.Size(256, 256);
            this.bM9.TabIndex = 8;
            this.bM9.UseVisualStyleBackColor = true;
            this.bM9.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM8
            // 
            this.bM8.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM8.Location = new System.Drawing.Point(353, 595);
            this.bM8.Name = "bM8";
            this.bM8.Size = new System.Drawing.Size(256, 256);
            this.bM8.TabIndex = 7;
            this.bM8.UseVisualStyleBackColor = true;
            this.bM8.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM7
            // 
            this.bM7.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM7.Location = new System.Drawing.Point(91, 595);
            this.bM7.Name = "bM7";
            this.bM7.Size = new System.Drawing.Size(256, 256);
            this.bM7.TabIndex = 6;
            this.bM7.UseVisualStyleBackColor = true;
            this.bM7.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM6
            // 
            this.bM6.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM6.Location = new System.Drawing.Point(615, 333);
            this.bM6.Name = "bM6";
            this.bM6.Size = new System.Drawing.Size(256, 256);
            this.bM6.TabIndex = 5;
            this.bM6.UseVisualStyleBackColor = true;
            this.bM6.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM5
            // 
            this.bM5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM5.Location = new System.Drawing.Point(353, 333);
            this.bM5.Name = "bM5";
            this.bM5.Size = new System.Drawing.Size(256, 256);
            this.bM5.TabIndex = 4;
            this.bM5.UseVisualStyleBackColor = true;
            this.bM5.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM4
            // 
            this.bM4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM4.Location = new System.Drawing.Point(91, 333);
            this.bM4.Name = "bM4";
            this.bM4.Size = new System.Drawing.Size(256, 256);
            this.bM4.TabIndex = 3;
            this.bM4.UseVisualStyleBackColor = true;
            this.bM4.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM3
            // 
            this.bM3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM3.Location = new System.Drawing.Point(615, 71);
            this.bM3.Name = "bM3";
            this.bM3.Size = new System.Drawing.Size(256, 256);
            this.bM3.TabIndex = 2;
            this.bM3.UseVisualStyleBackColor = true;
            this.bM3.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM2
            // 
            this.bM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM2.Location = new System.Drawing.Point(353, 71);
            this.bM2.Name = "bM2";
            this.bM2.Size = new System.Drawing.Size(256, 256);
            this.bM2.TabIndex = 1;
            this.bM2.UseVisualStyleBackColor = true;
            this.bM2.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // bM1
            // 
            this.bM1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bM1.Location = new System.Drawing.Point(91, 71);
            this.bM1.Name = "bM1";
            this.bM1.Size = new System.Drawing.Size(256, 256);
            this.bM1.TabIndex = 0;
            this.bM1.UseVisualStyleBackColor = true;
            this.bM1.Click += new System.EventHandler(this.Mbutton_click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(2968, 1748);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panelQ);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Tic-tac-toe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panelQ.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quantumToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rulesAndReferencesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quantumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creditsToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bC9;
        private System.Windows.Forms.Button bC8;
        private System.Windows.Forms.Button bC7;
        private System.Windows.Forms.Button bC6;
        private System.Windows.Forms.Button bC5;
        private System.Windows.Forms.Button bC4;
        private System.Windows.Forms.Button bC3;
        private System.Windows.Forms.Button bC2;
        private System.Windows.Forms.Button bC1;
        private System.Windows.Forms.ToolStripMenuItem misèreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classicToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem misèreToolStripMenuItem1;
        private System.Windows.Forms.Panel panelQ;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel2;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button bM9;
        private System.Windows.Forms.Button bM8;
        private System.Windows.Forms.Button bM7;
        private System.Windows.Forms.Button bM6;
        private System.Windows.Forms.Button bM5;
        private System.Windows.Forms.Button bM4;
        private System.Windows.Forms.Button bM3;
        private System.Windows.Forms.Button bM2;
        private System.Windows.Forms.Button bM1;
    }
}

